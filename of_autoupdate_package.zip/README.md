# ff14OceanFishing (auto-updating)

- Route codes are calculated client-side (no API).
- Route names + baits are loaded from `data/baits.json` (same-origin => stable).
- GitHub Actions updates `data/baits.json` daily from Lulu'sTools public spreadsheet.

## Setup (one time)
1) Settings → Pages → Deploy from branch → main / (root)
2) Settings → Actions → General → Workflow permissions → **Read and write permissions** → Save
3) Actions → "Update Ocean Fishing baits.json" → Run workflow
